--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 9.6.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: exchanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE exchanges (
    id bigint NOT NULL,
    name character varying NOT NULL,
    url character varying NOT NULL,
    xml_url character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_available boolean DEFAULT false NOT NULL,
    last_find_error character varying
);


--
-- Name: exchanges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE exchanges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exchanges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE exchanges_id_seq OWNED BY exchanges.id;


--
-- Name: payment_systems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE payment_systems (
    id bigint NOT NULL,
    name character varying NOT NULL,
    code character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: payment_systems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE payment_systems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_systems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE payment_systems_id_seq OWNED BY payment_systems.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id bigint NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    crypted_password character varying,
    salt character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    remember_me_token character varying,
    remember_me_token_expires_at timestamp without time zone,
    reset_password_token character varying,
    reset_password_token_expires_at timestamp without time zone,
    reset_password_email_sent_at timestamp without time zone,
    access_count_to_reset_password_page integer DEFAULT 0,
    failed_logins_count integer DEFAULT 0,
    lock_expires_at timestamp without time zone,
    unlock_token character varying,
    last_login_at timestamp without time zone,
    last_logout_at timestamp without time zone,
    last_activity_at timestamp without time zone,
    last_login_from_ip_address character varying,
    activation_state character varying,
    activation_token character varying,
    activation_token_expires_at timestamp without time zone,
    is_admin boolean DEFAULT false NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: exchanges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY exchanges ALTER COLUMN id SET DEFAULT nextval('exchanges_id_seq'::regclass);


--
-- Name: payment_systems id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment_systems ALTER COLUMN id SET DEFAULT nextval('payment_systems_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2019-03-22 15:47:33.663944	2019-03-23 08:13:34.591724
\.


--
-- Data for Name: exchanges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY exchanges (id, name, url, xml_url, created_at, updated_at, is_available, last_find_error) FROM stdin;
5	kassa.cc	https://kassa.cc	https://kassa.cc/valuta.xml	2019-03-22 15:47:37.787975	2019-03-22 15:47:37.787975	f	\N
8	WMCasher	https://wmcasher.ru	\N	2019-03-23 06:30:45.426982	2019-03-23 06:30:45.426982	f	\N
10	Wmt24	https://wmt24.ru	\N	2019-03-23 06:30:45.455961	2019-03-23 06:30:45.455961	f	\N
12	Обменник.ру	http://obmennik.ru	\N	2019-03-23 06:30:45.465221	2019-03-23 06:30:45.465221	f	\N
32	VIPchanger	https://vipchanger.com/	\N	2019-03-23 06:30:45.539979	2019-03-23 06:30:45.539979	f	\N
70	RocketChange	https://rocketchange.ru	\N	2019-03-23 06:30:45.660479	2019-03-23 06:30:45.660479	f	\N
11	Cashing	https://www.cashing.su	\N	2019-03-23 06:30:45.460688	2019-03-25 08:04:49.588549	f	404 Not Found
13	WMtoCash	https://wmtocash.com	\N	2019-03-23 06:30:45.469647	2019-03-25 08:05:50.716773	f	execution expired
16	Obmening	https://www.obmening.ru	\N	2019-03-23 06:30:45.481673	2019-03-25 08:09:07.159782	f	404 Not Found
21	UkrWebTransfer	https://ukrwebtransfer.com	\N	2019-03-23 06:30:45.500351	2019-03-25 08:09:16.583304	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (certificate has expired)
22	ExchangeX	https://exchangex.ru	\N	2019-03-23 06:30:45.5039	2019-03-25 08:09:17.099943	f	404 Not Found
23	WebObmen	https://www.webobmen.com	\N	2019-03-23 06:30:45.507561	2019-03-25 08:09:18.678083	f	404 
27	Exwp	http://exwp.com	\N	2019-03-23 06:30:45.521743	2019-03-25 08:09:20.544936	f	404 Not Found
28	WMAlliance	https://wmalliance.ru/	\N	2019-03-23 06:30:45.525215	2019-03-25 08:09:22.749352	f	404 Not Found
29	Wm72	https://obmen.wm72.com	\N	2019-03-23 06:30:45.528839	2019-03-25 08:09:24.68342	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (ok)
33	MasterChange	https://master-change.com.ua	\N	2019-03-23 06:30:45.543606	2019-03-25 08:09:31.093751	f	404 Not Found
35	SimpleChange	https://simplechange.ru	\N	2019-03-23 06:30:45.550408	2019-03-25 08:09:34.061948	f	404 Not Found
36	ExPayer	https://expayer.ru	\N	2019-03-23 06:30:45.553698	2019-03-25 08:09:34.585231	f	404 Not Found
37	ObmenAT	https://obmen.at/	\N	2019-03-23 06:30:45.556983	2019-03-25 08:09:36.303304	f	404 Not Found
39	MonsterChange	https://monsterchange.ru	\N	2019-03-23 06:30:45.568806	2019-03-25 08:09:39.205712	f	404 Not Found
42	XchangeMoney	https://xchange.money	\N	2019-03-23 06:30:45.578308	2019-03-25 08:09:41.16917	f	404 Not Found
43	ChangeMoney	https://www.changemoney.me	\N	2019-03-23 06:30:45.581439	2019-03-25 08:09:42.524519	f	404 Not Found
44	WMBlrClub	https://wmblr.club	\N	2019-03-23 06:30:45.584372	2019-03-25 08:09:43.202823	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
45	WmBlr	https://wmblr.ru	\N	2019-03-23 06:30:45.587285	2019-03-25 08:09:43.785127	f	404 Not Found
49	SafePay	https://safepay.com.ua	\N	2019-03-23 06:30:45.599231	2019-03-25 08:09:51.234628	f	404 Not Found
51	ExchangerWM	https://exchangerwm.com	\N	2019-03-23 06:30:45.605133	2019-03-25 08:09:52.786106	f	404 Not Found
52	UkrWM	https://ukrwm.com	\N	2019-03-23 06:30:45.60809	2019-03-25 08:09:53.534173	f	Failed to open TCP connection to ukrwm.com:443 (Connection refused - connect(2) for "ukrwm.com" port 443)
54	ВМТаганрог	https://wmtaganrog.ru/	\N	2019-03-23 06:30:45.614568	2019-03-25 08:09:53.893717	f	404 Not Found
55	OnlineChange	https://onlinechange.com/	\N	2019-03-23 06:30:45.617897	2019-03-25 08:09:55.705298	f	404 Not Found
61	WM-Obmen24	https://wm-obmen24.com	\N	2019-03-23 06:30:45.635762	2019-03-25 08:10:05.432149	f	Failed to open TCP connection to wm-obmen24.com:443 (Connection refused - connect(2) for "wm-obmen24.com" port 443)
69	ByWare	https://byware.net/	\N	2019-03-23 06:30:45.657778	2019-03-25 08:10:14.159641	f	403 Forbidden
73	UltraGold	https://ultragold.net	\N	2019-03-23 06:30:45.66834	2019-03-25 08:10:17.698521	f	404 Not Found
76	FlyChange	https://flychange.net	\N	2019-03-23 06:30:45.676425	2019-03-25 08:10:22.924592	f	404 NOT FOUND
83	ObmenMoney	https://obmen.money	\N	2019-03-23 06:30:45.694839	2019-03-25 08:10:36.886748	f	404 Not Found
116	NetEx24	https://www.netex24.net	\N	2019-03-23 06:30:45.797356	2019-03-23 06:30:45.797356	f	\N
131	P2PChange	https://p2pchange.is	\N	2019-03-23 06:30:45.835721	2019-03-23 06:30:45.835721	f	\N
165	24PayBank	https://24paybank.org/	\N	2019-03-23 06:30:45.922997	2019-03-23 06:30:45.922997	f	\N
82	ChangeAm	https://www.change.am	https://www.change.am/request-exportxml.xml	2019-03-23 06:30:45.692292	2019-04-01 17:49:39.560284	t	404 Not Found
59	LuxObmenka	https://luxobmenka.com	\N	2019-03-23 06:30:45.629903	2019-04-01 17:40:36.33457	f	403 Forbidden
81	1Exchanger	https://1exchanger.com	https://1exchanger.com/request-exportxml.xml	2019-03-23 06:30:45.689771	2019-04-01 17:49:37.604948	t	404 Not Found
38	Trust-Deal	https://trust-deal.ru	https://trust-deal.ru/request-exportxml.xml	2019-03-23 06:30:45.565507	2019-04-01 17:40:03.297503	f	404 Not Found
2	m-obmen.ru	https://m-obmen.ru	https://m-obmen.ru/ru/export/xml	2019-03-22 15:47:37.778161	2019-04-01 17:40:17.723931	t	\N
3	obmennik.ws	https://obmennik.ws	https://obmennik.ws/ru/export/xml	2019-03-22 15:47:37.781534	2019-04-01 17:40:18.212092	t	\N
46	FavoriteExchanger	https://favorite-exchanger.ru	https://favorite-exchanger.ru/request-exportxml.xml	2019-03-23 06:30:45.590238	2019-04-01 17:40:18.520119	f	404 Not Found
4	superobmenka.com	https://superobmenka.com	https://superobmenka.com/ru/export/xml	2019-03-22 15:47:37.784746	2019-04-01 17:40:18.686294	t	\N
47	Обменка	https://obmenka.online	https://obmenka.online/request-exportxml.xml	2019-03-23 06:30:45.593258	2019-04-01 17:40:20.788362	f	404 Not Found
58	BazarMoney	http://bazarmoney.ru	http://bazarmoney.ru/request-exportxml.xml	2019-03-23 06:30:45.626968	2019-04-01 17:40:36.294804	f	404 Not Found
60	Babasiki	https://babasiki.ru	https://babasiki.ru/request-exportxml.xml	2019-03-23 06:30:45.632807	2019-04-01 17:40:38.42102	f	404 Not Found
62	AlfaWM	https://www.alfawm.ru/	https://www.alfawm.ru//rates.xml	2019-03-23 06:30:45.63857	2019-04-01 17:40:40.411097	f	404 Not Found
65	iChanger	https://ichanger.net/	https://ichanger.net//rates.xml	2019-03-23 06:30:45.646969	2019-04-01 17:40:47.409723	f	404 Not Found
72	RealExchange	https://real-exchange.ru	https://real-exchange.ru/request-exportxml.xml	2019-03-23 06:30:45.665835	2019-04-01 17:40:57.916032	f	404 Not Found
75	WmzUa	http://wmzua.com	http://wmzua.com/rates.xml	2019-03-23 06:30:45.673756	2019-04-01 17:41:05.019723	f	404 Not Found
78	Обменкин	https://obmenkin.com	https://obmenkin.com/exportxml.xml	2019-03-23 06:30:45.681637	2019-04-01 17:41:11.424673	f	404 Not Found
150	1WM	https://1wm.kz	https://1wm.kz/exportxml.xml	2019-03-23 06:30:45.885198	2019-04-01 17:53:29.397076	t	\N
19	Обменник.ua	https://obmennik.ua	https://obmennik.ua/ru/export/xml	2019-03-23 06:30:45.493325	2019-04-01 17:49:27.810032	t	\N
24	WMStream	https://wmstream.ru/	https://wmstream.ru//ru/export/xml	2019-03-23 06:30:45.511158	2019-04-01 17:49:28.345923	t	\N
31	WM-Sha	https://wm-sha.ru	https://wm-sha.ru/ru/export/xml	2019-03-23 06:30:45.536435	2019-04-01 17:49:28.943715	t	\N
34	WmPayCash	https://wmpaycash.com	https://wmpaycash.com/ru/export/xml	2019-03-23 06:30:45.547037	2019-04-01 17:49:30.732177	t	\N
48	WM-Privat	https://wm-privat.com	https://wm-privat.com/ru/export/xml	2019-03-23 06:30:45.596281	2019-04-01 17:49:31.263294	t	\N
79	TopObmen	https://topobmen.ru	https://topobmen.ru/ru/export/xml	2019-03-23 06:30:45.684301	2019-04-01 17:49:31.777638	t	\N
20	WmBox	http://wmbox.com.ua/	http://wmbox.com.ua//request-exportxml.xml	2019-03-23 06:30:45.496837	2019-04-01 17:49:35.837968	t	404 Not Found
169	Bitcoin-Обмен	https://bitcoin-obmen.com/	\N	2019-03-23 06:30:45.932849	2019-03-23 06:30:45.932849	f	\N
87	WmzBy	http://wmzby.ru/	\N	2019-03-23 06:30:45.706583	2019-03-25 08:10:44.718154	f	404 Not Found
90	JoJoCash	https://jojo.cash	\N	2019-03-23 06:30:45.720037	2019-03-25 08:10:47.55614	f	404 Not Found
92	SaleWMZ	http://salewmz.kz/	\N	2019-03-23 06:30:45.726337	2019-03-25 08:10:49.863032	f	403 Forbidden
93	GreenCashWM	http://greencash-wm.ru/	\N	2019-03-23 06:30:45.729526	2019-03-25 08:10:50.478946	f	404 Not Found
94	Монетка	https://monetka.exchange	\N	2019-03-23 06:30:45.732591	2019-03-25 08:10:51.91638	f	404 Not Found
95	SpbWMCasher	https://spbwmcasher.ru	\N	2019-03-23 06:30:45.735667	2019-03-25 08:10:52.566196	f	404 Not Found
97	Owm24	https://owm24.com	\N	2019-03-23 06:30:45.741851	2019-03-25 08:10:55.64075	f	404 Not Found
99	Pro100obmen	https://pro100obmen.net	\N	2019-03-23 06:30:45.747943	2019-03-25 08:11:07.943899	f	404 Not Found
100	XMLGold	https://www.xmlgold.eu	\N	2019-03-23 06:30:45.751026	2019-03-25 08:11:08.502064	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
102	24Pay	https://24pay.me/	\N	2019-03-23 06:30:45.75691	2019-03-25 08:12:09.333344	f	execution expired
104	NixExchange	https://www.nixexchange.com/	\N	2019-03-23 06:30:45.762771	2019-03-25 08:15:09.4425	f	404 Not Found
105	UniChange	https://unichange.me	\N	2019-03-23 06:30:45.765731	2019-03-25 08:15:10.093866	f	404 Not Found
107	D-Obmen	https://d-obmen.cc	\N	2019-03-23 06:30:45.771569	2019-03-25 08:15:11.984308	f	404 Not Found
111	MagneticExchange	https://magneticexchange.com	\N	2019-03-23 06:30:45.783128	2019-03-25 08:15:15.543584	f	404 Not Found
112	X-Pay	https://x-pay.cc	\N	2019-03-23 06:30:45.785967	2019-03-25 08:15:16.559372	f	Failed to open TCP connection to x-pay.cc:443 (getaddrinfo: Name or service not known)
114	FehuPay	https://fehupay.com	\N	2019-03-23 06:30:45.791701	2019-03-25 08:15:23.400527	f	Net::ReadTimeout with #<TCPSocket:(closed)>
117	Ukr-Obmen	https://ukr-obmen.com	\N	2019-03-23 06:30:45.800176	2019-03-25 08:15:36.751676	f	404 Not Found
119	PM2BTC	https://pm2btc.me	\N	2019-03-23 06:30:45.805438	2019-03-25 08:15:50.146952	f	404 Not Found
120	PM2Cashin	https://pm2cashin.me	\N	2019-03-23 06:30:45.807963	2019-03-25 08:15:53.292104	f	404 Not Found
122	CC2BTC	https://cryptocheck2btc.me	\N	2019-03-23 06:30:45.81277	2019-03-25 08:15:55.6901	f	Failed to open TCP connection to cryptocheck2btc.me:443 (getaddrinfo: Name or service not known)
123	BTC2Cashin	https://btc2cashin.me	\N	2019-03-23 06:30:45.815214	2019-03-25 08:15:56.511405	f	404 Not Found
124	PM2WM	http://pm2wm.me	\N	2019-03-23 06:30:45.817784	2019-03-25 08:15:59.441748	f	404 Not Found
125	BTC2PM	https://btc2pm.me	\N	2019-03-23 06:30:45.820326	2019-03-25 08:16:02.94015	f	404 Not Found
126	BTC2WM	https://btc2wm.me	\N	2019-03-23 06:30:45.822845	2019-03-25 08:16:06.125243	f	404 Not Found
132	NetEx²	https://netex.me	\N	2019-03-23 06:30:45.838312	2019-03-25 08:16:09.246737	f	404 Not Found
136	E-Scrooge	https://e-scrooge.is	\N	2019-03-23 06:30:45.848115	2019-03-25 08:16:27.242637	f	404 Not Found
138	QuickChange	https://quickchange.cc	\N	2019-03-23 06:30:45.853145	2019-03-25 08:16:34.448324	f	404 NOT FOUND
142	Cryptex24	https://cryptex24.com	\N	2019-03-23 06:30:45.865125	2019-03-25 08:16:42.070816	f	404 Not Found
143	WMGlobus	https://wmglobus.com	\N	2019-03-23 06:30:45.867681	2019-03-25 08:16:42.484012	f	404 Not Found
144	E-Money	https://e-money.cc	\N	2019-03-23 06:30:45.870326	2019-03-25 08:16:42.708153	f	503 Service Temporarily Unavailable
146	ArbitrCoin	https://arbitrcoin.com	\N	2019-03-23 06:30:45.875377	2019-03-25 08:16:43.63081	f	404 Not Found
148	GoodObmen	https://goodobmen.com	\N	2019-03-23 06:30:45.880316	2019-03-25 08:16:49.018536	f	404 Not Found
149	LiteObmen	https://liteobmen.com	\N	2019-03-23 06:30:45.882707	2019-03-25 08:16:49.528156	f	404 Not Found
154	Обмен.cc	https://obmen.cc/	\N	2019-03-23 06:30:45.896017	2019-03-25 08:16:51.470705	f	404 Not Found
155	PayToChina	https://paytochina.com	\N	2019-03-23 06:30:45.89861	2019-03-25 08:16:52.23712	f	404 Not Found
158	Smart-Pays	https://smart-pays.com	\N	2019-03-23 06:30:45.905844	2019-03-25 08:17:00.143556	f	Net::ReadTimeout with #<TCPSocket:(closed)>
159	PayBis	https://paybis.com	\N	2019-03-23 06:30:45.908375	2019-03-25 08:17:12.528828	f	404 Not Found
160	MoneyChange	https://money-change.biz	\N	2019-03-23 06:30:45.910834	2019-03-25 08:17:14.388592	f	404 Not Found
163	TytCoin	https://tytcoin.com	\N	2019-03-23 06:30:45.918074	2019-03-25 08:17:47.171881	f	403 Forbidden
166	WealthPay	https://wealthpay.org	\N	2019-03-23 06:30:45.925513	2019-03-25 08:17:50.175182	f	404 Not Found
172	ImExchanger	https://imexchanger.pro	\N	2019-03-23 06:30:45.940515	2019-03-25 08:17:53.411417	f	404 Not Found
171	WorldChange	https://worldchange.cc/	https://worldchange.cc//ru/export/xml	2019-03-23 06:30:45.93798	2019-03-25 08:17:53.342512	f	404 Not Found
175	ChangerClub	http://changer.club/ru/	\N	2019-03-23 06:30:45.947949	2019-03-23 06:30:45.947949	f	\N
176	C-Cex	https://c-cex.com/	\N	2019-03-23 06:30:45.951642	2019-03-23 06:30:45.951642	f	\N
15	WMChange	https://wmchange.in.ua	https://wmchange.in.ua/export/xml	2019-03-23 06:30:45.477917	2019-03-23 07:19:42.677431	f	\N
18	M-Obmen	http://m-obmen.ru	http://m-obmen.ru/ru/export/xml	2019-03-23 06:30:45.48989	2019-03-23 07:25:06.071469	f	\N
25	WMChange24	https://wmchange24.net	https://wmchange24.net/ru/export/xml	2019-03-23 06:30:45.514644	2019-03-23 07:25:21.045724	f	\N
71	Vmex	https://vmex.info	https://vmex.info/ru/export/xml	2019-03-23 06:30:45.663201	2019-03-23 07:38:58.479105	f	\N
110	Xchange	https://xchange.cash/	\N	2019-03-23 06:30:45.780304	2019-04-01 17:50:42.925697	f	404 Not Found
88	5Минут	http://5min.su	http://5min.su/request-exportxml.xml	2019-03-23 06:30:45.709433	2019-04-01 17:41:46.725873	f	404 Not Found
86	IgnExchange	https://ignexchange.com	\N	2019-03-23 06:30:45.703731	2019-04-01 17:41:42.043572	f	404 Not Found
108	Обменник24	https://obmennik24.net	https://obmennik24.net/ru/export/xml	2019-03-23 06:30:45.774537	2019-04-01 17:49:40.764129	t	\N
145	BelkaPay	https://belkapay.com	https://belkapay.com/panel/export-rates/type/xml	2019-03-23 06:30:45.872795	2019-04-01 17:49:43.027628	t	404 Not Found
106	Changer	https://www.changer.com	\N	2019-03-23 06:30:45.768657	2019-04-01 17:50:36.401379	f	404 Not Found
135	PM-Obmen	https://pm-obmen.tv	\N	2019-03-23 06:30:45.84572	2019-04-01 17:52:52.709537	f	404 Not Found
137	N-Obmen	https://n-obmen.net	https://n-obmen.net/request-exportxml.xml	2019-03-23 06:30:45.850637	2019-04-01 17:53:03.888036	f	404 Not Found
139	MisterMoneyBrasil	https://www.mistermoneybrasil.com	https://www.mistermoneybrasil.com/exportxml.xml	2019-03-23 06:30:45.855776	2019-04-01 17:53:05.646688	f	404 Not Found
141	SolidChanger	https://solidchanger.com	https://solidchanger.com/request-exportxml.xml	2019-03-23 06:30:45.862642	2019-04-01 17:53:13.696625	f	404 Not Found
147	GoldObmen	https://goldobmen.com	https://goldobmen.com/request-exportxml.xml	2019-03-23 06:30:45.877848	2019-04-01 17:53:24.872394	f	404 Not Found
151	365Cash	https://365cash.co	https://365cash.co/bestchange.xml	2019-03-23 06:30:45.888502	2019-04-01 17:53:30.86598	f	404 Not Found
153	Обмен-Ом	https://obmen-om.com	https://obmen-om.com/rates.xml	2019-03-23 06:30:45.893524	2019-04-01 17:53:32.096961	f	404 Not Found
157	Bit-Changer	https://bit-changer.net	\N	2019-03-23 06:30:45.903456	2019-04-01 17:53:40.619682	f	redirection forbidden: https://bit-changer.net/bestchange.xml -> http://bit-changer.net/bestchange.xml/
161	Z-Obmen	https://z-obmen.ru/	https://z-obmen.ru//request-exportxml.xml	2019-03-23 06:30:45.913233	2019-04-01 17:54:32.175384	f	Net::ReadTimeout with #<TCPSocket:(closed)>
162	ObmennCom	https://obmenn.com/	https://obmenn.com//request-exportxml.xml	2019-03-23 06:30:45.915642	2019-04-01 17:54:45.731503	f	404 Not Found
164	24Обмен	https://24obmen.org	https://24obmen.org/rates.xml	2019-03-23 06:30:45.92053	2019-04-01 17:54:52.77985	f	404 Not Found
89	MonEx	https://monex.me	https://monex.me/_export/exchange_xml/	2019-03-23 06:30:45.71679	2019-03-23 07:39:35.340638	f	\N
103	E-Obmen	https://e-obmen.net	https://e-obmen.net/ru/export/xml	2019-03-23 06:30:45.759845	2019-03-23 07:44:02.812165	f	\N
170	WMCentre	https://wmcentre.kz/	https://wmcentre.kz//ru/export/xml	2019-03-23 06:30:45.935401	2019-03-23 07:47:46.758283	f	\N
174	SuperChangeNet	https://superchange.net	https://superchange.net/ru/export/xml	2019-03-23 06:30:45.94543	2019-03-23 07:47:52.216011	f	\N
356	ObmenCash	https://obmen.cash	\N	2019-03-25 08:04:37.781087	2019-03-25 08:04:37.781087	f	\N
361	BitExchanger	https://bit-exchanger.ru	\N	2019-03-25 08:04:37.791659	2019-03-25 08:04:37.791659	f	\N
177	YoBit	https://yobit.io	\N	2019-03-23 06:30:45.954237	2019-03-25 08:17:56.487586	f	404 Not Found
180	Changelly	https://ru.changelly.com	\N	2019-03-23 06:30:45.961736	2019-03-25 08:18:08.010283	f	404 Not Found
337	Changer4u	https://changer4u.com	\N	2019-03-25 08:04:37.737487	2019-03-25 08:19:12.27899	f	404 Not Found
336	UltraChange²	0	\N	2019-03-25 08:04:37.66931	2019-03-25 08:19:12.074082	f	No such file or directory @ rb_sysopen - 0/valuta.xml
338	WW-Pay	https://ww-pay.com	https://ww-pay.com/export/xml	2019-03-25 08:04:37.740322	2019-03-25 08:19:13.510557	f	404 Not Found
341	FastChange	https://fastchange.me	\N	2019-03-25 08:04:37.747624	2019-03-25 08:19:15.336405	f	403 Forbidden
350	Vilkov	https://vilkov.com	\N	2019-03-25 08:04:37.768106	2019-03-25 08:23:21.751411	f	404 Not Found
351	Magnatus	http://magnatus.com	\N	2019-03-25 08:04:37.770369	2019-03-25 08:23:22.43045	f	404 Not Found
352	PMCash	https://pmcash.kz	https://pmcash.kz/ru/export/xml	2019-03-25 08:04:37.772499	2019-03-25 08:23:23.721221	f	404 Not Found
358	OpenChange	https://openchange.me	\N	2019-03-25 08:04:37.785334	2019-03-25 08:23:38.398142	f	404 Not Found
360	UniObmen	http://uniobmen.ru	\N	2019-03-25 08:04:37.789548	2019-03-25 08:24:43.634082	f	execution expired
364	PayGet	https://payget.pro	\N	2019-03-25 08:04:37.797702	2019-03-25 08:27:58.353467	f	403 Forbidden
366	RuBitok	https://rubitok.com	\N	2019-03-25 08:04:37.801773	2019-03-25 08:27:59.853456	f	404 Not Found
367	UltraObmen	https://ultraobmen.net	\N	2019-03-25 08:04:37.803804	2019-03-25 08:28:00.449731	f	404 Not Found
375	TierraPay	https://tierrapay.com	\N	2019-03-25 08:04:37.819557	2019-03-25 08:28:20.923748	f	404 Not Found
377	Trust-Changer	https://trust-changer.com	\N	2019-03-25 08:04:37.823513	2019-03-25 08:28:22.416117	f	503 Service Temporarily Unavailable
384	SimplExchange	https://simplexchange.net	\N	2019-03-25 08:04:37.8368	2019-03-25 08:28:34.922388	f	404 Not Found
386	Cashex	https://cashex.cc	\N	2019-03-25 08:04:37.840636	2019-03-25 08:28:46.337987	f	404 Not Found
395	ExchangeBlue	https://www.exchange.blue	\N	2019-03-25 08:04:37.858407	2019-03-25 08:30:17.302521	f	404 Not Found
397	WuBill	https://wubill.com	\N	2019-03-25 08:04:37.862373	2019-03-25 08:30:22.511761	f	404 Not Found
399	Валютчик	https://valutchik.com	\N	2019-03-25 08:04:37.866316	2019-03-25 08:30:29.246481	f	404 Not Found
414	BestCoin	https://bestcoin.cc	\N	2019-03-25 08:04:37.895426	2019-03-25 08:04:37.895426	f	\N
446	Конверт	https://konvert.im	\N	2019-03-25 08:04:37.956476	2019-03-25 08:04:37.956476	f	\N
482	Bitlish	https://bitlish.com	\N	2019-03-25 08:04:38.033029	2019-03-25 08:04:38.033029	f	\N
485	TheRockTrading	https://www.therocktrading.com	\N	2019-03-25 08:04:38.039284	2019-03-25 08:04:38.039284	f	\N
407	Your-Coins	https://your-coins.com	\N	2019-03-25 08:04:37.881559	2019-03-25 08:30:51.94171	f	404 Not Found
409	Ru-Bas	https://ru-bas.ru	\N	2019-03-25 08:04:37.885428	2019-03-25 08:30:55.425807	f	404 Not Found
410	Bchange	https://bchange.cc	\N	2019-03-25 08:04:37.887458	2019-03-25 08:30:55.972758	f	404 Not Found
379	100Btc	https://100btc.pro	https://100btc.pro/request-exportxml.xml	2019-03-25 08:04:37.827355	2019-04-01 18:05:16.803404	f	404 Not Found
178	Bit-Обменка	https://bit-obmenka.com	https://bit-obmenka.com/request-exportxml.xml	2019-03-23 06:30:45.956702	2019-04-01 17:55:15.281452	f	404 Not Found
373	YChanger	https://ychanger.net	\N	2019-03-25 08:04:37.815584	2019-04-01 18:04:57.171145	f	404 Not Found
382	Coinex24	https://coinex24.com	https://coinex24.com/request-exportxml.xml	2019-03-25 08:04:37.832995	2019-04-01 18:05:21.209442	f	404 Not Found
340	BaksMan	https://baksman.org	\N	2019-03-25 08:04:37.745186	2019-04-01 17:55:26.535358	f	404 Not Found
390	Pocket-Exchange	https://pocket-exchange.com	https://pocket-exchange.com/valuta.xml	2019-03-25 08:04:37.848438	2019-04-01 17:49:47.461376	t	404 Not Found
346	7Money	https://7money.co	https://7money.co/utils/export?type=xml	2019-03-25 08:04:37.759251	2019-04-01 17:49:49.464337	t	404 Not Found
342	Банкомат	https://bankcomat.com	\N	2019-03-25 08:04:37.749927	2019-04-01 17:55:28.968631	f	404 Not Found
343	El-Change	https://el-change.com	https://el-change.com/request-exportxml.xml	2019-03-25 08:04:37.75228	2019-04-01 17:55:31.45985	f	404 Not Found
345	eBitok	https://ebitok.com	\N	2019-03-25 08:04:37.756865	2019-04-01 17:55:31.81465	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (certificate has expired)
349	GeeExchange	https://geeexchange.ru	https://geeexchange.ru/exportxml.xml	2019-03-25 08:04:37.765819	2019-04-01 17:55:36.872964	f	\N
353	ExMoney	https://exmoney.me	https://exmoney.me/exportxml.xml	2019-03-25 08:04:37.774701	2019-04-01 17:55:42.292266	f	404 Not Found
354	RuChange	https://ru-change.cc	https://ru-change.cc/request-exportxml.xml	2019-03-25 08:04:37.776812	2019-04-01 17:55:45.628092	f	404 Not Found
357	24BestEx	https://24bestex.com	https://24bestex.com/request-exportxml.xml	2019-03-25 08:04:37.783235	2019-04-01 17:56:03.368323	f	404 Not Found
359	Transfer24	https://transfer24.pro	https://transfer24.pro/request-exportxml.xml	2019-03-25 08:04:37.787464	2019-04-01 17:56:14.288676	f	404 Not Found
363	Star5Exchange	http://star5.exchange	http://star5.exchange/request-exportxml.xml	2019-03-25 08:04:37.795696	2019-04-01 18:04:25.38633	f	404 Not Found
369	CoinToCard	https://cointocard.org	https://cointocard.org/request-exportxml.xml	2019-03-25 08:04:37.80777	2019-04-01 18:04:49.222189	f	404 Not Found
368	MinedTrade	https://minedtrade.com	\N	2019-03-25 08:04:37.80575	2019-04-01 18:04:43.712584	f	404 Not Found
374	КэшБанк	https://cashbank.pro	https://cashbank.pro/request-exportxml.xml	2019-03-25 08:04:37.817438	2019-04-01 18:05:02.041364	f	404 Not Found
378	50Cents	https://50cents.pro	https://50cents.pro/exportxml.xml	2019-03-25 08:04:37.825388	2019-04-01 18:05:14.79765	f	404 Not Found
381	BetaTransfer	https://betatransfer.net	https://betatransfer.net/request-exportxml.xml	2019-03-25 08:04:37.831158	2019-04-01 18:05:20.237163	f	404 Not Found
385	MegaBestObmen	https://www.megabestobmen.com	\N	2019-03-25 08:04:37.838739	2019-04-01 18:05:36.610679	f	404 Not Found
388	MyCryptoMarket	https://mycrypto.market	https://mycrypto.market/request-exportxml.xml	2019-03-25 08:04:37.844565	2019-04-01 18:06:05.016374	f	404 Not Found
394	GoodExchanger	https://good-exchanger.com	https://good-exchanger.com/request-exportxml.xml	2019-03-25 08:04:37.85635	2019-04-01 18:06:14.716236	f	404 Not Found
400	Обменио	https://obmen.io	https://obmen.io/request-exportxml.xml	2019-03-25 08:04:37.868194	2019-04-01 18:06:40.375157	f	404 Not Found
396	Pay-Today	https://pay-today.cc	https://pay-today.cc/request-exportxml.xml	2019-03-25 08:04:37.860249	2019-04-01 18:06:21.553698	f	404 Not Found
401	1-Online	https://1-online.ru	https://1-online.ru/request-exportxml.xml	2019-03-25 08:04:37.87026	2019-04-01 18:06:51.889816	f	404 Not Found
408	Шахта	http://xn--80aa7cln.com	http://xn--80aa7cln.com/request-exportxml.xml	2019-03-25 08:04:37.883513	2019-04-01 18:07:02.513579	f	404 Not Found
442	LasloBit	https://laslobit.cc	https://laslobit.cc/request-exportxml.xml	2019-03-25 08:04:37.948855	2019-04-01 18:09:23.820541	f	404 Not Found
415	BitStore	https://bitstore.ws	\N	2019-03-25 08:04:37.89749	2019-03-25 08:31:17.546482	f	404 NOT FOUND
421	UltraChange24	https://ultrachange24.com	\N	2019-03-25 08:04:37.909169	2019-03-25 08:31:26.339065	f	404 Not Found
423	E-Armor	https://e-armor.me	\N	2019-03-25 08:04:37.912984	2019-03-25 08:31:28.393906	f	404 Not Found
431	Zanachka-Pay	http://zanachka-pay.com	\N	2019-03-25 08:04:37.928262	2019-03-25 08:32:03.32222	f	503 Service Temporarily Unavailable
434	Exchanger-em	https://exchanger-em.com	https://exchanger-em.com/export/xml	2019-03-25 08:04:37.934037	2019-03-25 08:32:09.325583	f	404 Not Found
438	CoinHubb	https://coinhubb.com	https://coinhubb.com/_export/exchange_xml/	2019-03-25 08:04:37.941722	2019-03-25 08:32:20.027212	f	\N
440	AlphaPay24	https://alphapay24.com	\N	2019-03-25 08:04:37.945315	2019-03-25 08:32:21.640508	f	404 Not Found
441	Payeer	https://payeer.com	\N	2019-03-25 08:04:37.947109	2019-03-25 08:32:22.263679	f	404 Not Found
445	NetExchange	https://www.netexchange.ru	\N	2019-03-25 08:04:37.954692	2019-03-25 08:32:26.952402	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
449	4Exchange	https://4exchange.cash	\N	2019-03-25 08:04:37.962271	2019-03-25 08:32:33.994275	f	404 Not Found
454	O-Paxum	https://o-paxum.net	\N	2019-03-25 08:04:37.981647	2019-03-25 08:32:36.653411	f	404 Not Found
455	BitPayeers	https://bitpayes.com	\N	2019-03-25 08:04:37.983431	2019-03-25 08:32:37.490064	f	401 Authorization Required
458	WmExpress	https://wm.express	\N	2019-03-25 08:04:37.988611	2019-03-25 08:32:43.297834	f	404 Not Found
463	Биткоин24	https://bitcoin24.com.ua	\N	2019-03-25 08:04:37.996971	2019-03-25 08:32:48.015611	f	404 Not Found
464	Paspar	https://paspar.net	\N	2019-03-25 08:04:37.998727	2019-03-25 08:32:48.461551	f	404 Not Found
468	MoneyExchange	https://me24.com.ua	\N	2019-03-25 08:04:38.005349	2019-03-25 08:32:56.841872	f	404 Not Found
469	WEX	https://wex.fit	\N	2019-03-25 08:04:38.007269	2019-03-25 08:32:58.182065	f	Failed to open TCP connection to wex.fit:443 (getaddrinfo: Name or service not known)
470	Poloniex	https://poloniex.com	\N	2019-03-25 08:04:38.008875	2019-03-25 08:32:58.347482	f	404 Not Found
472	LiveCoin	https://www.livecoin.net	\N	2019-03-25 08:04:38.012464	2019-03-25 08:36:59.626791	f	520 Origin Error
473	Bitfinex	https://www.bitfinex.com	\N	2019-03-25 08:04:38.014577	2019-03-25 08:37:01.486115	f	404 Not Found
474	Cexio	https://cex.io	\N	2019-03-25 08:04:38.016514	2019-03-25 08:37:02.106634	f	404 Not Found
475	Kraken	https://www.kraken.com	\N	2019-03-25 08:04:38.018696	2019-03-25 08:37:04.250842	f	404 Not Found
476	Ecoin	https://www.ecoin.eu	\N	2019-03-25 08:04:38.020636	2019-03-25 08:37:08.680096	f	404 Not Found
478	ItBit	https://www.itbit.com	\N	2019-03-25 08:04:38.024708	2019-03-25 08:37:10.934165	f	404 Not Found
479	OkCoin	https://www.okcoin.com	\N	2019-03-25 08:04:38.026822	2019-03-25 08:37:12.82647	f	404 
481	CryptoMate	https://cryptomate.co.uk	\N	2019-03-25 08:04:38.03085	2019-03-25 08:37:16.241316	f	404 Not Found
483	Bitkonan	https://bitkonan.com/	\N	2019-03-25 08:04:38.03512	2019-03-25 08:37:17.422184	f	wrong header line format
484	Gemini	https://gemini.com	\N	2019-03-25 08:04:38.037075	2019-03-25 08:37:18.654177	f	404 Not Found
486	Binance	https://www.binance.com	\N	2019-03-25 08:04:38.041399	2019-03-25 08:37:22.436491	f	404 Not Found
489	BitBay	https://auth.bitbay.net	\N	2019-03-25 08:04:38.047836	2019-03-25 08:04:38.047836	f	\N
6	SaveChange	https://www.savechange.ru	\N	2019-03-23 06:30:45.404678	2019-03-25 08:04:42.66673	f	404 Not Found
9	Обменник.in.ua	https://obmennik.in.ua	\N	2019-03-23 06:30:45.433495	2019-03-25 08:04:44.76482	f	503 Service Temporarily Unavailable
392	Ym-Change	https://ym-change.com	\N	2019-03-25 08:04:37.852302	2019-03-25 08:30:10.665538	f	404 Not Found
30	Меняйко	https://меняйко.com.ua	\N	2019-03-23 06:30:45.532583	2019-03-25 08:09:24.970953	f	URI must be ascii only "https://\\u043C\\u0435\\u043D\\u044F\\u0439\\u043A\\u043E.com.ua/valuta.xml"
40	ObmenTech	https://obmen.tech/	\N	2019-03-23 06:30:45.571974	2019-03-25 08:09:39.933971	f	404 Not Found
50	PayPalPartner	https://partner.exchange/	\N	2019-03-23 06:30:45.602101	2019-03-25 08:09:51.855195	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (certificate has expired)
53	НаКарту	https://nakartu.com	\N	2019-03-23 06:30:45.611323	2019-03-25 08:09:53.589163	f	Failed to open TCP connection to nakartu.com:443 (getaddrinfo: Name or service not known)
391	FastExchange	https://fastexchange.center	https://fastexchange.center/request-exportxml.xml	2019-03-25 08:04:37.850482	2019-04-01 18:06:06.699925	f	404 Not Found
439	ChangeMoney24	https://changemoney24.ru	https://changemoney24.ru/request-exportxml.xml	2019-03-25 08:04:37.943552	2019-04-01 18:09:18.526212	f	404 Not Found
417	DBChange	https://dbchange.ru	https://dbchange.ru/request-exportxml.xml	2019-03-25 08:04:37.901442	2019-04-01 18:07:43.717737	f	404 Not Found
17	Спасибо	https://spasibo.kz/	\N	2019-03-23 06:30:45.486451	2019-04-01 17:39:08.268492	f	404 Not Found
26	2Cash	https://2cash.ru/	\N	2019-03-23 06:30:45.51825	2019-04-01 17:39:28.777141	f	404 Компонент не найден!
41	Exch-em	https://exch-em.com/	\N	2019-03-23 06:30:45.575157	2019-04-01 17:40:06.099457	f	503 Service Temporarily Unavailable
412	CashOnline	https://cashonline.cc	https://cashonline.cc/valuta.xml	2019-03-25 08:04:37.891231	2019-04-01 17:49:54.646954	t	404 Not Found
456	OwlChange	https://owlchange.com	https://owlchange.com/valuta.xml	2019-03-25 08:04:37.985082	2019-04-01 17:49:57.765952	t	404 Not Found
413	CryptoPay24	https://cryptopay24.com	\N	2019-03-25 08:04:37.893086	2019-04-01 18:07:37.36221	f	404 Not Found
416	BtcTenge	https://btctenge.com	https://btctenge.com/request-exportxml.xml	2019-03-25 08:04:37.899513	2019-04-01 18:07:42.786746	f	404 Not Found
420	BestObmen	https://bestobmen.su	https://bestobmen.su/request-exportxml.xml	2019-03-25 08:04:37.907275	2019-04-01 18:07:50.081948	t	404 Not Found
424	FastEx	https://fastex.su	https://fastex.su/request-exportxml.xml	2019-03-25 08:04:37.915051	2019-04-01 18:08:01.136412	f	404 Not Found
425	Perfect-Change	https://perfect-change.com	https://perfect-change.com/request-exportxml.xml	2019-03-25 08:04:37.91688	2019-04-01 18:08:10.888838	f	404 Not Found
427	99Francs	https://99francs.pro	https://99francs.pro/bestchange.xml	2019-03-25 08:04:37.920677	2019-04-01 18:08:26.38351	f	404 Not Found
429	NewLine	https://newline.online	https://newline.online/request-exportxml.xml	2019-03-25 08:04:37.924452	2019-04-01 18:08:44.428006	f	Net::ReadTimeout with #<TCPSocket:(closed)>
430	BtcBit	https://btcbit.net	https://btcbit.net/bestchange.xml	2019-03-25 08:04:37.926417	2019-04-01 18:08:47.279342	f	404 Not Found
435	Staff-Obmen	https://staff-obmen.com	https://staff-obmen.com/request-exportxml.xml	2019-03-25 08:04:37.935861	2019-04-01 18:09:12.715242	f	404 Not Found
447	Payforia	https://payforia.net	https://payforia.net/request-exportxml.xml	2019-03-25 08:04:37.958533	2019-04-01 18:09:32.965295	f	404 Not Found
450	ObmenPP	https://obmenpp.com.ua	https://obmenpp.com.ua/rates.xml	2019-03-25 08:04:37.964058	2019-04-01 18:09:37.477965	f	404 Not Found
452	BuyBit	https://buybit.net	https://buybit.net/bestchange.xml	2019-03-25 08:04:37.978321	2019-04-01 18:09:39.413732	f	404 Not Found
457	Easy-Changer	https://easy-changer.ru	https://easy-changer.ru/request-exportxml.xml	2019-03-25 08:04:37.986956	2019-04-01 18:09:44.28623	f	404 Not Found
460	VV-Obmen	https://vv-obmen.ru	https://vv-obmen.ru/request-exportxml.xml	2019-03-25 08:04:37.992013	2019-04-01 18:09:48.469645	f	404 Not Found
465	Smart-Obmen	https://smart-obmen.com	https://smart-obmen.com/request-exportxml.xml	2019-03-25 08:04:38.000346	2019-04-01 18:09:55.00014	f	404 Not Found
466	Midas24	https://midas24.biz	https://midas24.biz/rates.xml	2019-03-25 08:04:38.002094	2019-04-01 18:09:57.025585	f	404 Not Found
56	Pay-Exchange	https://pay-exchange.com	\N	2019-03-23 06:30:45.621059	2019-03-25 08:09:55.965549	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
63	eCashMe	https://www.ecashme.ru	\N	2019-03-23 06:30:45.641437	2019-03-25 08:10:07.539076	f	404 Not Found
64	My-Xchange	https://my-xchange.com	\N	2019-03-23 06:30:45.644255	2019-03-25 08:10:08.811944	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
66	Обмен24	https://обмен24.com	\N	2019-03-23 06:30:45.649702	2019-03-25 08:10:10.029863	f	URI must be ascii only "https://\\u043E\\u0431\\u043C\\u0435\\u043D24.com/valuta.xml"
77	WestChange²	https://westchange.top	\N	2019-03-23 06:30:45.678988	2019-03-25 08:10:23.377521	f	403 Forbidden
85	GetExchange	https://getexchange.ru	\N	2019-03-23 06:30:45.700568	2019-03-25 08:10:43.20965	f	404 Not Found
101	SuperChange	https://superchange.is	\N	2019-03-23 06:30:45.753991	2019-03-25 08:11:08.886595	f	404 Not Found
109	UkrCash	https://ukrcash.com	\N	2019-03-23 06:30:45.777458	2019-03-25 08:15:12.576411	f	Failed to open TCP connection to ukrcash.com:443 (Connection refused - connect(2) for "ukrcash.com" port 443)
113	A-Exchange	https://a-exchange.com	\N	2019-03-23 06:30:45.788868	2019-03-25 08:15:17.104837	f	404 Not Found
118	NXT	https://nxt.am	\N	2019-03-23 06:30:45.802766	2019-03-25 08:15:40.36271	f	Failed to open TCP connection to nxt.am:443 (No route to host - connect(2) for "nxt.am" port 443)
121	CC2Cashin	https://cryptocheck2cashin.me	\N	2019-03-23 06:30:45.810365	2019-03-25 08:15:55.275367	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (certificate has expired)
127	CC2PM	https://cryptocheck2pm.me	\N	2019-03-23 06:30:45.825458	2019-03-25 08:16:08.268405	f	Failed to open TCP connection to cryptocheck2pm.me:443 (getaddrinfo: Name or service not known)
128	PM2CC	https://pm2cryptocheck.me	\N	2019-03-23 06:30:45.827953	2019-03-25 08:16:08.295524	f	Failed to open TCP connection to pm2cryptocheck.me:443 (getaddrinfo: Name or service not known)
129	CC2WM	https://cryptocheck2wm.me	\N	2019-03-23 06:30:45.830542	2019-03-25 08:16:08.322934	f	Failed to open TCP connection to cryptocheck2wm.me:443 (getaddrinfo: Name or service not known)
130	BTC2CC	https://btc2cryptocheck.me	\N	2019-03-23 06:30:45.833125	2019-03-25 08:16:08.349917	f	Failed to open TCP connection to btc2cryptocheck.me:443 (getaddrinfo: Name or service not known)
133	I-Obmen	https://i-obmen.biz	\N	2019-03-23 06:30:45.840894	2019-03-25 08:16:09.472863	f	503 Service Temporarily Unavailable
134	Changex	https://changex.com	\N	2019-03-23 06:30:45.843243	2019-03-25 08:16:09.797934	f	404 Not Found
347	A1Change	https://a1change.com	https://a1change.com/export/xml	2019-03-25 08:04:37.76141	2019-03-25 08:23:19.845001	f	404 Not Found
348	60сек	https://60cek.org	\N	2019-03-25 08:04:37.763717	2019-03-25 08:23:19.968306	f	403 Forbidden
380	ExchangeBox	https://exchangebox.biz	\N	2019-03-25 08:04:37.829186	2019-03-25 08:28:30.20875	f	Failed to open TCP connection to exchangebox.biz:443 (getaddrinfo: Name or service not known)
387	MarketCoin	https://marketcoin.io	\N	2019-03-25 08:04:37.842639	2019-03-25 08:29:58.617472	f	Failed to open TCP connection to marketcoin.io:443 (Connection refused - connect(2) for "marketcoin.io" port 443)
402	Z-Exchange	https://z-exchange.ru	\N	2019-03-25 08:04:37.872062	2019-03-25 08:30:46.073177	f	503 Service Temporarily Unavailable
406	ChBy	https://chby.ru	\N	2019-03-25 08:04:37.879734	2019-03-25 08:30:51.254059	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
411	МеняйПро	http://xn--e1aihfgfh1j.xn--p1ai	\N	2019-03-25 08:04:37.889338	2019-03-25 08:31:00.433209	f	Net::ReadTimeout with #<TCPSocket:(closed)>
433	BitMonsters	https://exchange.bitmonsters.net	\N	2019-03-25 08:04:37.932094	2019-03-25 08:32:07.437819	f	404 Not Found
436	Incrypto	https://exchange.incrypto.org	\N	2019-03-25 08:04:37.937891	2019-03-25 08:32:17.669505	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (ok)
451	ObmenoFF	https://obmenoff.cc	\N	2019-03-25 08:04:37.976047	2019-03-25 08:32:35.166428	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
487	Bittrex	http://outdatedbrowser.com	\N	2019-03-25 08:04:38.043628	2019-03-25 08:37:23.478563	f	404 Not Found
488	CoinBase	https://www.coinbase.com	\N	2019-03-25 08:04:38.045706	2019-03-25 08:37:24.122407	f	404 Not Found
459	All24	https://all24.cc	\N	2019-03-25 08:04:37.990418	2019-03-25 08:32:43.366709	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
461	BTC2Pay	https://btc2pay.ru	\N	2019-03-25 08:04:37.993593	2019-03-25 08:32:46.100589	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
471	Exmo	https://exmo.me	\N	2019-03-25 08:04:38.010609	2019-03-25 08:33:59.082463	f	execution expired
480	HitBtc	https://hitbtc.com	\N	2019-03-25 08:04:38.028725	2019-03-25 08:37:14.348314	f	404 Not Found
419	1Обмен	https://1obmen.ru	https://1obmen.ru/request-exportxml.xml	2019-03-25 08:04:37.905293	2019-04-01 17:38:53.466863	f	503 Service Temporarily Unavailable
14	24-Exchange	https://24-exchange.com	https://24-exchange.com/exportxml.xml	2019-03-23 06:30:45.47375	2019-04-01 17:38:53.472436	f	Net::ReadTimeout with #<TCPSocket:(closed)>
339	24Obmin	https://24obmin.com	https://24obmin.com/rates.html?sType=estandarts_xml	2019-03-25 08:04:37.742802	2019-04-01 17:38:53.478026	f	404 Not Found
490	8pay.ru	https://8pay.ru	https://8pay.ru/requests/best.php	2019-04-01 17:38:53.494195	2019-04-01 17:38:53.494195	f	\N
491	acryptoexchange.com	https://acryptoexchange.com	https://acryptoexchange.com/request-exportxml.xml?lang=ru	2019-04-01 17:38:53.500128	2019-04-01 17:38:53.500128	f	\N
115	AlfaCashier	https://www.alfacashier.com	https://www.alfacashier.com/api/rates	2019-03-23 06:30:45.794546	2019-04-01 17:38:53.505213	f	404 Not Found
57	Echange	https://echange.su	https://echange.su/request-exportxml.xml	2019-03-23 06:30:45.624023	2019-04-01 17:40:32.759168	f	404 Not Found
67	WMSim	http://www.wmsim.ru	http://www.wmsim.ru/rates.xml	2019-03-23 06:30:45.652455	2019-04-01 17:40:53.514783	f	\N
98	CashTransfers	https://cash-transfers.com	\N	2019-03-23 06:30:45.744958	2019-04-01 17:42:27.134284	f	404 Not Found
404	Ферма	https://ferma.cc	https://ferma.cc/valuta.xml	2019-03-25 08:04:37.875954	2019-04-01 17:50:04.314308	t	404 Not Found
376	PokPay	https://pokpay.com	https://pokpay.com/ru/export/xml	2019-03-25 08:04:37.821529	2019-04-01 17:50:05.510916	t	500 Internal Server Error
7	Cashinout	https://www.cashinout.ru	https://www.cashinout.ru/rates.xml	2019-03-23 06:30:45.421314	2019-04-01 17:50:08.090063	t	404 Not Found
344	100Монет	https://100monet.pro	https://100monet.pro/bestchange.xml	2019-03-25 08:04:37.754701	2019-04-01 17:50:09.208162	t	\N
167	F-Change	https://f-change.biz/	https://f-change.biz//request-exportxml.xml	2019-03-23 06:30:45.927951	2019-04-01 17:54:55.686527	f	404 Not Found
173	Lionex	https://lionex.net/	https://lionex.net//rates.xml	2019-03-23 06:30:45.94296	2019-04-01 17:55:07.060182	f	404 Not Found
179	ShapeShift	https://ru.shapeshift.io	\N	2019-03-23 06:30:45.959173	2019-04-01 17:55:15.44806	f	503 Service Temporarily Unavailable
181	Real-Bit	https://real-bit.ru	https://real-bit.ru/request-exportxml.xml	2019-03-23 06:30:45.964256	2019-04-01 17:55:22.202754	f	404 Not Found
365	ProstoCash	https://prostocash.com	\N	2019-03-25 08:04:37.79977	2019-04-01 18:04:27.837183	f	404 Not Found
444	100BtcKiev	https://100btc.kiev.ua	https://100btc.kiev.ua/request-exportxml.xml	2019-03-25 08:04:37.95268	2019-04-01 18:09:27.061408	f	404 Not Found
448	HotExchange	http://hotexchange.ru	http://hotexchange.ru/request-exportxml.xml	2019-03-25 08:04:37.960305	2019-04-01 18:09:34.718684	f	404 Not Found
493	allmoney.market	https://allmoney.market	https://allmoney.market/public/rates.xml	2019-04-01 17:38:53.514671	2019-04-01 17:38:53.514671	f	\N
494	btc24.pro	https://btc24.pro	https://btc24.pro/rates/rates.xml	2019-04-01 17:38:53.529045	2019-04-01 17:38:53.529045	f	\N
495	banknew.su	https://banknew.su	https://banknew.su/monitor.xml	2019-04-01 17:38:53.534819	2019-04-01 17:38:53.534819	f	\N
496	belqi.net	https://belqi.net	https://belqi.net/request-exportxml.xml	2019-04-01 17:38:53.55068	2019-04-01 17:38:53.55068	f	\N
498	bigbank.cash	https://bigbank.cash	https://bigbank.cash/exportxml.xml	2019-04-01 17:38:53.578592	2019-04-01 17:38:53.578592	f	\N
499	bit-changer.net	http://bit-changer.net	http://bit-changer.net/storage/rates/xml/short.xml	2019-04-01 17:38:53.583472	2019-04-01 17:38:53.583472	f	\N
500	bit-plant.com	https://bit-plant.com	https://bit-plant.com/exportxml.xml	2019-04-01 17:38:53.588201	2019-04-01 17:38:53.588201	f	\N
501	bitobmen.net	https://bitobmen.net	https://bitobmen.net/exportxml.xml	2019-04-01 17:38:53.5979	2019-04-01 17:38:53.5979	f	\N
502	bitpro.pro	https://bitpro.pro	https://bitpro.pro/exportxml.xml	2019-04-01 17:38:53.602352	2019-04-01 17:38:53.602352	f	\N
503	bitcoins.md	https://bitcoins.md	https://bitcoins.md/exportxml.xml	2019-04-01 17:38:53.616341	2019-04-01 17:38:53.616341	f	\N
504	bittrend.pro	https://bittrend.pro	https://bittrend.pro/exportxml.xml	2019-04-01 17:38:53.625416	2019-04-01 17:38:53.625416	f	\N
505	bonanza-obmen.com	https://bonanza-obmen.com	https://bonanza-obmen.com/exportxml.xml	2019-04-01 17:38:53.629605	2019-04-01 17:38:53.629605	f	\N
506	bonkypay.com	https://bonkypay.com	https://bonkypay.com/exportxml.xml	2019-04-01 17:38:53.633999	2019-04-01 17:38:53.633999	f	\N
405	BtcChange24	https://btcchange24.com	https://btcchange24.com/exportxml.xml	2019-03-25 08:04:37.87797	2019-04-01 17:38:53.638836	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
428	Buy-Bitcoins	https://buy-bitcoin.pro	https://buy-bitcoin.pro/exportxml.xml	2019-03-25 08:04:37.922635	2019-04-01 17:38:53.648735	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
507	byware.net	https://byware.net	https://byware.net/exportxml.xml	2019-04-01 17:38:53.65341	2019-04-01 17:38:53.65341	f	\N
508	cashadmin.ru	https://cashadmin.ru	https://cashadmin.ru/exportxml.xml	2019-04-01 17:38:53.657744	2019-04-01 17:38:53.657744	f	\N
1	e-dengi.org	https://e-dengi.org	https://e-dengi.org/_export/exchange_xml/	2019-03-22 15:47:37.770038	2019-04-01 17:40:16.641303	t	\N
492	all.cash	https://all.cash	https://all.cash/valuta.xml	2019-04-01 17:38:53.509821	2019-04-01 17:50:12.013853	t	\N
497	big-changer.ru	https://big-changer.ru	https://big-changer.ru/exportxml.xml	2019-04-01 17:38:53.573619	2019-04-01 17:50:12.960458	t	\N
371	Bitochek	https://bitochek.net	https://bitochek.net/request-exportxml.xml	2019-03-25 08:04:37.811667	2019-04-01 18:04:54.744968	f	404 Not Found
393	ArmChange	https://idram.armchange.ru	https://idram.armchange.ru/request-exportxml.xml	2019-03-25 08:04:37.854407	2019-04-01 18:06:11.107743	f	404 Not Found
398	BTC-Online	https://btc-online.net	https://btc-online.net/request-exportxml.xml	2019-03-25 08:04:37.864206	2019-04-01 18:06:32.348982	f	404 Not Found
422	Bitcoin24Exchange	https://bitcoin24.exchange	https://bitcoin24.exchange/request-exportxml.xml	2019-03-25 08:04:37.911126	2019-04-01 18:07:53.622198	f	404 Not Found
74	MegaChange	http://www.megachange.ru	http://www.megachange.ru/request-exportxml.xml	2019-03-23 06:30:45.670965	2019-04-01 17:41:04.160497	f	404 Not Found
84	ObmenTop	http://obmentop.kz/	\N	2019-03-23 06:30:45.697533	2019-04-01 17:41:40.089154	f	redirection forbidden: https://obmentop.kz/bestchange.xml -> http://obmentop.kz/404.php
91	V-Obmen²	http://v-obmen.net	http://v-obmen.net/exportxml.xml	2019-03-23 06:30:45.723204	2019-04-01 17:41:50.319326	f	404 Not Found
96	LiCash	https://licash.top	\N	2019-03-23 06:30:45.738761	2019-04-01 17:41:58.014439	f	500 Internal Server Error
80	RootPay	https://rootpay.ru	https://rootpay.ru/ru/export/xml	2019-03-23 06:30:45.687102	2019-04-01 17:49:32.316953	t	\N
443	EuroBitcoins	https://eurobitcoins.org	https://eurobitcoins.org/export/xml	2019-03-25 08:04:37.950898	2019-04-01 17:50:06.560174	t	404 Not Found
140	SolidChangerNet	https://solidchanger.net	https://solidchanger.net/request-exportxml.xml	2019-03-23 06:30:45.859955	2019-04-01 17:53:08.771957	f	404 Not Found
152	F1Ex	https://f1ex.com	\N	2019-03-23 06:30:45.891002	2019-04-01 17:53:31.068794	f	404 Not Found
156	Receive-Money	https://receive-money.biz	https://receive-money.biz/request-exportxml.xml	2019-03-23 06:30:45.901047	2019-04-01 17:53:39.974019	f	404 Not Found
168	RapidObmen	https://rapid-obmen.com	https://rapid-obmen.com/request-exportxml.xml	2019-03-23 06:30:45.930452	2019-04-01 17:54:59.347644	f	404 Not Found
355	Coin-Bank	https://coin-bank.co	https://coin-bank.co/request-exportxml.xml	2019-03-25 08:04:37.778976	2019-04-01 17:55:48.03317	f	404 Not Found
362	Makoli	https://makoli.com	https://makoli.com/request-exportxml.xml	2019-03-25 08:04:37.793626	2019-04-01 18:04:19.92121	f	404 Not Found
370	UniEx	https://uniex.co	https://uniex.co/rates.xml	2019-03-25 08:04:37.80972	2019-04-01 18:04:50.062543	f	404 Not Found
372	Best-Obmen	https://best-obmen.com	https://best-obmen.com/request-exportxml.xml	2019-03-25 08:04:37.813792	2019-04-01 18:04:55.826294	f	404 Not Found
383	LeoExchanger	https://leoexchanger.top	\N	2019-03-25 08:04:37.834968	2019-04-01 18:05:33.188614	f	404 Not Found
389	IndaCoin	https://indacoin.com	\N	2019-03-25 08:04:37.846574	2019-04-01 18:06:05.292696	f	404 Not Found
403	SBitcoin	https://sbitcoin.ru	https://sbitcoin.ru/request-exportxml.xml	2019-03-25 08:04:37.874201	2019-04-01 18:06:56.815109	f	404 Not Found
418	CryptoMoney	https://cryptomoney.pro	https://cryptomoney.pro/request-exportxml.xml	2019-03-25 08:04:37.903409	2019-04-01 18:07:47.349952	f	404 Not Found
426	2x2Change	https://2x2change.com	https://2x2change.com/request-exportxml.xml	2019-03-25 08:04:37.918851	2019-04-01 18:08:21.204232	f	404 Not Found
432	Qipri	https://qipri.com	https://qipri.com/request-exportxml.xml	2019-03-25 08:04:37.930244	2019-04-01 18:08:51.83154	f	404 Not Found
437	Bitcoin24SU	https://bitcoin24.su	https://bitcoin24.su/request-exportxml.xml	2019-03-25 08:04:37.939958	2019-04-01 18:09:17.066055	f	404 Not Found
453	BTCBank	https://btcbank.com.ua:443	https://btcbank.com.ua:443/rates.xml	2019-03-25 08:04:37.980013	2019-04-01 18:09:40.040488	f	404 Not Found
462	WMSell	https://wmsell.biz	https://wmsell.biz/request-exportxml.xml	2019-03-25 08:04:37.995357	2019-04-01 18:09:50.664123	f	404 Not Found
467	Иеремия76	https://ieremia76.com	https://ieremia76.com/request-exportxml.xml	2019-03-25 08:04:38.003709	2019-04-01 18:09:59.987899	f	404 Not Found
477	BitStamp	https://ru.bitstamp.net	\N	2019-03-25 08:04:38.022773	2019-04-01 18:18:22.879683	f	SSL_connect returned=1 errno=0 state=error: certificate verify failed (unable to get local issuer certificate)
68	FastWM	https://fastwm.biz/	https://fastwm.biz/ru/export/xml	2019-03-23 06:30:45.655122	2019-04-03 06:49:47.318335	f	404 Not Found
\.


--
-- Name: exchanges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('exchanges_id_seq', 508, true);


--
-- Data for Name: payment_systems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY payment_systems (id, name, code, created_at, updated_at) FROM stdin;
1	QWRUB	QWRUB	2019-03-22 16:36:05.864903	2019-03-22 16:36:05.864903
2	WMZ	WMZ	2019-03-22 16:36:05.873491	2019-03-22 16:36:05.873491
3	WMR	WMR	2019-03-22 16:36:05.882758	2019-03-22 16:36:05.882758
4	WME	WME	2019-03-22 16:36:05.889815	2019-03-22 16:36:05.889815
5	P24UAH	P24UAH	2019-03-22 16:36:05.896441	2019-03-22 16:36:05.896441
6	WMB	WMB	2019-03-22 16:36:05.903021	2019-03-22 16:36:05.903021
7	YAMRUB	YAMRUB	2019-03-22 16:36:05.914774	2019-03-22 16:36:05.914774
8	WMU	WMU	2019-03-22 16:36:05.922407	2019-03-22 16:36:05.922407
9	SBERRUB	SBERRUB	2019-03-22 16:36:14.414211	2019-03-22 16:36:14.414211
10	ACRUB	ACRUB	2019-03-22 16:36:14.439218	2019-03-22 16:36:14.439218
11	TCSBRUB	TCSBRUB	2019-03-22 16:36:14.463744	2019-03-22 16:36:14.463744
12	CARDRUB	CARDRUB	2019-03-22 16:36:14.486358	2019-03-22 16:36:14.486358
13	TBRUB	TBRUB	2019-03-22 16:36:14.513895	2019-03-22 16:36:14.513895
14	CARDUAH	CARDUAH	2019-03-22 16:36:14.554276	2019-03-22 16:36:14.554276
15	WMK	WMK	2019-03-22 16:36:22.377768	2019-03-22 16:36:22.377768
16	PMUSD	PMUSD	2019-03-22 16:36:31.856525	2019-03-22 16:36:31.856525
17	BTC	BTC	2019-03-22 16:36:31.871927	2019-03-22 16:36:31.871927
18	PMVUSD	PMVUSD	2019-03-22 16:36:31.879649	2019-03-22 16:36:31.879649
19	PRUSD	PRUSD	2019-03-22 16:36:31.935727	2019-03-22 16:36:31.935727
20	LTC	LTC	2019-03-22 16:36:31.969556	2019-03-22 16:36:31.969556
21	ETH	ETH	2019-03-22 16:36:32.01128	2019-03-22 16:36:32.01128
22	ADVCUSD	ADVCUSD	2019-03-22 16:36:32.087954	2019-03-22 16:36:32.087954
23	PRRUB	PRRUB	2019-03-22 16:36:32.153947	2019-03-22 16:36:32.153947
24	ADVCRUB	ADVCRUB	2019-03-22 16:36:32.233567	2019-03-22 16:36:32.233567
25	DASH	DASH	2019-03-22 16:36:32.29833	2019-03-22 16:36:32.29833
26	XRP	XRP	2019-03-22 16:36:32.379954	2019-03-22 16:36:32.379954
27	ETC	ETC	2019-03-22 16:36:32.467028	2019-03-22 16:36:32.467028
28	EXMUSD	EXMUSD	2019-03-22 16:36:32.559541	2019-03-22 16:36:32.559541
29	EXMRUB	EXMRUB	2019-03-22 16:36:32.636204	2019-03-22 16:36:32.636204
30	BCH	BCH	2019-03-22 16:36:32.739323	2019-03-22 16:36:32.739323
31	CASHRUB	CASHRUB	2019-03-23 08:22:18.860524	2019-03-23 08:22:18.860524
32	WMX	WMX	2019-03-23 08:22:18.973863	2019-03-23 08:22:18.973863
33	PSBRUB	PSBRUB	2019-03-23 08:22:18.980914	2019-03-23 08:22:18.980914
34	CASHUSD	CASHUSD	2019-03-23 08:22:19.182282	2019-03-23 08:22:19.182282
35	WUUSD	WUUSD	2019-03-23 08:22:19.189061	2019-03-23 08:22:19.189061
36	CARDUSD	CARDUSD	2019-03-23 08:22:19.193319	2019-03-23 08:22:19.193319
37	PMEUR	PMEUR	2019-03-23 08:22:19.475974	2019-03-23 08:22:19.475974
38	ADVCEUR	ADVCEUR	2019-03-23 08:22:19.484397	2019-03-23 08:22:19.484397
39	WIRERUB	WIRERUB	2019-03-23 08:22:19.989218	2019-03-23 08:22:19.989218
40	RUSSTRUB	RUSSTRUB	2019-03-23 08:22:19.995246	2019-03-23 08:22:19.995246
41	MONOBUAH	MONOBUAH	2019-03-23 08:22:20.283203	2019-03-23 08:22:20.283203
42	WMG	WMG	2019-03-23 08:22:20.294358	2019-03-23 08:22:20.294358
43	ADVCUAH	ADVCUAH	2019-03-23 08:22:20.524584	2019-03-23 08:22:20.524584
44	WORUB	WORUB	2019-03-23 08:22:20.530881	2019-03-23 08:22:20.530881
45	WOUAH	WOUAH	2019-03-23 08:22:20.534461	2019-03-23 08:22:20.534461
46	WOUSD	WOUSD	2019-03-23 08:22:20.538076	2019-03-23 08:22:20.538076
47	STLMRUB	STLMRUB	2019-03-23 08:22:20.884803	2019-03-23 08:22:20.884803
48	PPUSD	PPUSD	2019-03-23 08:22:20.907658	2019-03-23 08:22:20.907658
49	WIREEUR	WIREEUR	2019-03-23 08:22:20.919355	2019-03-23 08:22:20.919355
50	WIREUSD	WIREUSD	2019-03-23 08:22:20.927412	2019-03-23 08:22:20.927412
51	XMR	XMR	2019-03-23 08:22:20.934587	2019-03-23 08:22:20.934587
52	PREUR	PREUR	2019-03-23 08:22:20.938322	2019-03-23 08:22:20.938322
53	EPMUSD	EPMUSD	2019-03-23 08:22:20.94085	2019-03-23 08:22:20.94085
54	EPMEUR	EPMEUR	2019-03-23 08:22:20.963579	2019-03-23 08:22:20.963579
55	ACCUSD	ACCUSD	2019-03-23 08:22:20.965525	2019-03-23 08:22:20.965525
56	ACCRUB	ACCRUB	2019-03-23 08:22:20.975708	2019-03-23 08:22:20.975708
57	ADVCKZT	ADVCKZT	2019-03-23 08:22:22.384775	2019-03-23 08:22:22.384775
58	NIXUSD	NIXUSD	2019-03-23 08:22:22.389973	2019-03-23 08:22:22.389973
59	NIXEUR	NIXEUR	2019-03-23 08:22:22.394314	2019-03-23 08:22:22.394314
60	VLSPKZT	VLSPKZT	2019-03-23 08:22:22.401564	2019-03-23 08:22:22.401564
61	KKBKZT	KKBKZT	2019-03-23 08:22:22.407295	2019-03-23 08:22:22.407295
62	HLKBKZT	HLKBKZT	2019-03-23 08:22:22.411024	2019-03-23 08:22:22.411024
63	SBERKZT	SBERKZT	2019-03-23 08:22:22.416615	2019-03-23 08:22:22.416615
64	KSPBKZT	KSPBKZT	2019-03-23 08:22:22.420968	2019-03-23 08:22:22.420968
65	FRTBKZT	FRTBKZT	2019-03-23 08:22:22.425602	2019-03-23 08:22:22.425602
66	CARDKZT	CARDKZT	2019-03-23 08:22:22.430419	2019-03-23 08:22:22.430419
67	WIREKZT	WIREKZT	2019-03-23 08:22:22.43549	2019-03-23 08:22:22.43549
68	EKZT	EKZT	2019-03-23 08:22:22.440236	2019-03-23 08:22:22.440236
69	USDT	USDT	2019-03-23 08:22:22.45003	2019-03-23 08:22:22.45003
70	EXMEUR	EXMEUR	2019-03-23 08:22:22.457338	2019-03-23 08:22:22.457338
71	VLSPUSD	VLSPUSD	2019-03-23 08:22:22.464307	2019-03-23 08:22:22.464307
72	VLSPEUR	VLSPEUR	2019-03-23 08:22:22.468996	2019-03-23 08:22:22.468996
73	VLSPRUB	VLSPRUB	2019-03-23 08:22:22.473448	2019-03-23 08:22:22.473448
74	QWKZT	QWKZT	2019-03-23 08:22:22.480351	2019-03-23 08:22:22.480351
75	ATNBKZT	ATNBKZT	2019-03-25 08:13:32.751807	2019-03-25 08:13:32.751807
76	ERSNBKZT	ERSNBKZT	2019-03-25 08:23:36.7065	2019-03-25 08:23:36.7065
77	GCMTUSD	GCMTUSD	2019-03-25 08:23:36.716633	2019-03-25 08:23:36.716633
79	KUKRUB	KUKRUB	2019-03-25 08:23:36.724611	2019-03-25 08:23:36.724611
80	beeline	beeline	2019-03-25 08:23:36.728976	2019-03-25 08:23:36.728976
81	ZEC	ZEC	2019-03-25 08:31:09.744653	2019-03-25 08:31:09.744653
82	TRX	TRX	2019-03-25 08:31:09.752405	2019-03-25 08:31:09.752405
83	DOGE	DOGE	2019-03-25 08:31:09.756698	2019-03-25 08:31:09.756698
84	OMG	OMG	2019-03-25 08:31:09.761679	2019-03-25 08:31:09.761679
85	TUSD	TUSD	2019-03-25 08:31:09.764642	2019-03-25 08:31:09.764642
86	XLM	XLM	2019-03-25 08:31:09.772632	2019-03-25 08:31:09.772632
87	EXMBTC	EXMBTC	2019-03-25 08:32:36.515625	2019-03-25 08:32:36.515625
88	LVCNUSD	LVCNUSD	2019-03-25 08:32:36.520108	2019-03-25 08:32:36.520108
89	XEM	XEM	2019-03-25 08:33:09.206269	2019-03-25 08:33:09.206269
90	QTUM	QTUM	2019-03-25 08:33:09.219756	2019-03-25 08:33:09.219756
91	EOS	EOS	2019-03-25 08:33:09.235096	2019-03-25 08:33:09.235096
92	NEO	NEO	2019-03-25 08:33:09.244809	2019-03-25 08:33:09.244809
93	REP	REP	2019-03-25 08:33:09.257243	2019-03-25 08:33:09.257243
94	ZIL	ZIL	2019-03-25 08:33:09.266808	2019-03-25 08:33:09.266808
95	ZRX	ZRX	2019-03-25 08:33:09.278843	2019-03-25 08:33:09.278843
97	CASHEUR	CASHEUR	2019-04-01 17:30:39.278017	2019-04-01 17:30:39.278017
98	OSDBUAH	OSDBUAH	2019-04-01 17:49:04.942022	2019-04-01 17:49:04.942022
99	PMBBUAH	PMBBUAH	2019-04-01 17:49:04.953976	2019-04-01 17:49:04.953976
100	RFBUAH	RFBUAH	2019-04-01 17:49:04.966019	2019-04-01 17:49:04.966019
101	RNKBRUB	RNKBRUB	2019-04-01 17:49:04.973136	2019-04-01 17:49:04.973136
102	LQUSD	LQUSD	2019-04-01 17:49:04.976822	2019-04-01 17:49:04.976822
103	USBUAH	USBUAH	2019-04-01 17:49:04.978932	2019-04-01 17:49:04.978932
104	BLSBBYR	BLSBBYR	2019-04-01 17:49:04.984277	2019-04-01 17:49:04.984277
105	CARDEUR	CARDEUR	2019-04-01 17:49:04.99208	2019-04-01 17:49:04.99208
106	CARDBYN	CARDBYN	2019-04-01 17:49:04.995456	2019-04-01 17:49:04.995456
107	PPRUB	PPRUB	2019-04-01 17:49:05.962391	2019-04-01 17:49:05.962391
108	PPEUR	PPEUR	2019-04-01 17:49:05.973859	2019-04-01 17:49:05.973859
109	SKLUSD	SKLUSD	2019-04-01 17:49:05.993668	2019-04-01 17:49:05.993668
110	SKLEUR	SKLEUR	2019-04-01 17:49:06.001174	2019-04-01 17:49:06.001174
111	QWUSD	QWUSD	2019-04-01 17:49:06.076935	2019-04-01 17:49:06.076935
112	CNTRUB	CNTRUB	2019-04-01 17:49:06.084251	2019-04-01 17:49:06.084251
113	GCMTRUB	GCMTRUB	2019-04-01 17:49:06.091182	2019-04-01 17:49:06.091182
114	QWEUR	QWEUR	2019-04-01 17:49:06.095022	2019-04-01 17:49:06.095022
115	CNTUSD	CNTUSD	2019-04-01 17:49:06.098966	2019-04-01 17:49:06.098966
116	USTMUSD	USTMUSD	2019-04-01 17:49:06.106955	2019-04-01 17:49:06.106955
117	BOCUSD	BOCUSD	2019-04-01 17:49:06.112609	2019-04-01 17:49:06.112609
118	MGUSD	MGUSD	2019-04-01 17:49:06.121159	2019-04-01 17:49:06.121159
119	CASHKZT	CASHKZT	2019-04-01 17:49:06.129362	2019-04-01 17:49:06.129362
120	ZPRUB	ZPRUB	2019-04-01 17:49:06.133163	2019-04-01 17:49:06.133163
121	OKRUB	OKRUB	2019-04-01 17:49:06.133762	2019-04-01 17:49:06.133762
122	MGEUR	MGEUR	2019-04-01 17:49:06.13816	2019-04-01 17:49:06.13816
123	CAMUSD	CAMUSD	2019-04-01 17:49:08.217905	2019-04-01 17:49:08.217905
124	EDRM	EDRM	2019-04-01 17:49:08.223282	2019-04-01 17:49:08.223282
125	CASHAMD	CASHAMD	2019-04-01 17:49:08.233262	2019-04-01 17:49:08.233262
126	PPGBP	PPGBP	2019-04-01 17:49:08.247726	2019-04-01 17:49:08.247726
127	PPPLN	PPPLN	2019-04-01 17:49:08.258967	2019-04-01 17:49:08.258967
128	USTMRUB	USTMRUB	2019-04-01 17:49:08.274476	2019-04-01 17:49:08.274476
129	CASHUAH	CASHUAH	2019-04-01 17:49:08.280726	2019-04-01 17:49:08.280726
130	POBUSD	POBUSD	2019-04-01 17:49:08.291282	2019-04-01 17:49:08.291282
131	EPAYUSD	EPAYUSD	2019-04-01 17:49:08.310812	2019-04-01 17:49:08.310812
132	MIRCRUB	MIRCRUB	2019-04-01 17:49:08.319114	2019-04-01 17:49:08.319114
133	CARDAMD	CARDAMD	2019-04-01 17:49:08.324469	2019-04-01 17:49:08.324469
134	CARDGEL	CARDGEL	2019-04-01 17:49:08.329423	2019-04-01 17:49:08.329423
135	TBCBUSD	TBCBUSD	2019-04-01 17:49:08.334626	2019-04-01 17:49:08.334626
136	TBCBEUR	TBCBEUR	2019-04-01 17:49:08.338236	2019-04-01 17:49:08.338236
137	INFXUSD	INFXUSD	2019-04-01 17:49:08.340872	2019-04-01 17:49:08.340872
139	BSV	BSV	2019-04-01 17:49:11.798859	2019-04-01 17:49:11.798859
140	PAXUMUSD	PAXUMUSD	2019-04-01 17:49:11.808919	2019-04-01 17:49:11.808919
141	Ostalnyiekriptovalyutyibolee100vidov	Ostalnyiekriptovalyutyibolee100vidov	2019-04-01 17:49:11.828748	2019-04-01 17:49:11.828748
142	IOTA	IOTA	2019-04-01 17:49:11.83835	2019-04-01 17:49:11.83835
143	BTG	BTG	2019-04-01 17:49:11.84392	2019-04-01 17:49:11.84392
144	WIREUAH	WIREUAH	2019-04-01 17:49:11.850501	2019-04-01 17:49:11.850501
145	ADA	ADA	2019-04-01 17:49:11.859082	2019-04-01 17:49:11.859082
146	XVG	XVG	2019-04-01 17:49:11.870562	2019-04-01 17:49:11.870562
147	USDC	USDC	2019-04-01 17:49:11.87883	2019-04-01 17:49:11.87883
148	XBETRUB	XBETRUB	2019-04-01 17:49:11.884311	2019-04-01 17:49:11.884311
149	BNB	BNB	2019-04-01 17:49:11.885432	2019-04-01 17:49:11.885432
150	BAB	BAB	2019-04-01 17:49:11.895838	2019-04-01 17:49:11.895838
151	LSK	LSK	2019-04-01 17:49:11.903813	2019-04-01 17:49:11.903813
152	RFBRUB	RFBRUB	2019-04-01 17:49:11.90544	2019-04-01 17:49:11.90544
153	BTT	BTT	2019-04-01 17:49:11.910127	2019-04-01 17:49:11.910127
154	KMD	KMD	2019-04-01 17:49:11.913808	2019-04-01 17:49:11.913808
155	ICX	ICX	2019-04-01 17:49:11.916559	2019-04-01 17:49:11.916559
156	RMTFUSD	RMTFUSD	2019-04-01 17:49:11.920774	2019-04-01 17:49:11.920774
157	Denezhnyieperevodyi	Denezhnyieperevodyi	2019-04-01 17:49:11.922635	2019-04-01 17:49:11.922635
158	Qtum	Qtum	2019-04-01 17:49:11.9274	2019-04-01 17:49:11.9274
159	VeChain	VeChain	2019-04-01 17:49:11.929534	2019-04-01 17:49:11.929534
160	HOLO	HOLO	2019-04-01 17:49:11.932137	2019-04-01 17:49:11.932137
161	BAT	BAT	2019-04-01 17:49:11.934797	2019-04-01 17:49:11.934797
162	FET	FET	2019-04-01 17:49:11.936805	2019-04-01 17:49:11.936805
163	NULS	NULS	2019-04-01 17:49:11.939093	2019-04-01 17:49:11.939093
164	PAX	PAX	2019-04-01 17:49:11.941148	2019-04-01 17:49:11.941148
165	LINK	LINK	2019-04-01 17:49:11.943181	2019-04-01 17:49:11.943181
166	USDS	USDS	2019-04-01 17:49:11.947399	2019-04-01 17:49:11.947399
167	NPXS	NPXS	2019-04-01 17:49:11.949239	2019-04-01 17:49:11.949239
168	Decred	Decred	2019-04-01 17:49:11.951463	2019-04-01 17:49:11.951463
169	STEEM	STEEM	2019-04-01 17:49:11.953144	2019-04-01 17:49:11.953144
170	DENT	DENT	2019-04-01 17:49:11.955143	2019-04-01 17:49:11.955143
171	AION	AION	2019-04-01 17:49:11.956883	2019-04-01 17:49:11.956883
172	Ontology	Ontology	2019-04-01 17:49:11.958776	2019-04-01 17:49:11.958776
173	cashusd	cashusd	2019-04-01 17:49:13.752027	2019-04-01 17:49:13.752027
174	cashuah	cashuah	2019-04-01 17:49:13.755917	2019-04-01 17:49:13.755917
181	USD	USD	2019-04-01 17:49:15.484344	2019-04-01 17:49:15.484344
223	DSH	DSH	2019-04-01 17:49:16.818342	2019-04-01 17:49:16.818342
138	WAVES	WAVES	2019-04-01 17:49:08.364386	2019-04-01 17:49:08.364386
175	CUPCNY	CUPCNY	2019-04-01 17:49:14.93647	2019-04-01 17:49:14.93647
176	THIBTHB	THIBTHB	2019-04-01 17:49:14.942377	2019-04-01 17:49:14.942377
177	FLPNCAD	FLPNCAD	2019-04-01 17:49:14.948353	2019-04-01 17:49:14.948353
178	OPNBRUB	OPNBRUB	2019-04-01 17:49:14.966433	2019-04-01 17:49:14.966433
179	MWRUB	MWRUB	2019-04-01 17:49:14.973717	2019-04-01 17:49:14.973717
180	MWUAH	MWUAH	2019-04-01 17:49:14.979674	2019-04-01 17:49:14.979674
182	MTSRUB	MTSRUB	2019-04-01 17:49:16.283809	2019-04-01 17:49:16.283809
183	BLNRUB	BLNRUB	2019-04-01 17:49:16.300182	2019-04-01 17:49:16.300182
184	MGFNRUB	MGFNRUB	2019-04-01 17:49:16.305793	2019-04-01 17:49:16.305793
185	TELE2RUB	TELE2RUB	2019-04-01 17:49:16.312255	2019-04-01 17:49:16.312255
186	AVBRUB	AVBRUB	2019-04-01 17:49:16.33093	2019-04-01 17:49:16.33093
187	MTSBRUB	MTSBRUB	2019-04-01 17:49:16.342495	2019-04-01 17:49:16.342495
188	SWIFTUSD	SWIFTUSD	2019-04-01 17:49:16.350204	2019-04-01 17:49:16.350204
189	SWIFTEUR	SWIFTEUR	2019-04-01 17:49:16.356624	2019-04-01 17:49:16.356624
190	NTLRUSD	NTLRUSD	2019-04-01 17:49:16.397026	2019-04-01 17:49:16.397026
191	NTLREUR	NTLREUR	2019-04-01 17:49:16.404285	2019-04-01 17:49:16.404285
192	BNBRUB	BNBRUB	2019-04-01 17:49:16.430796	2019-04-01 17:49:16.430796
193	OTPBRUB	OTPBRUB	2019-04-01 17:49:16.444854	2019-04-01 17:49:16.444854
194	ROSBRUB	ROSBRUB	2019-04-01 17:49:16.453474	2019-04-01 17:49:16.453474
195	UNCBRUB	UNCBRUB	2019-04-01 17:49:16.46196	2019-04-01 17:49:16.46196
196	VOSTBRUB	VOSTBRUB	2019-04-01 17:49:16.471789	2019-04-01 17:49:16.471789
197	GPBRUB	GPBRUB	2019-04-01 17:49:16.479719	2019-04-01 17:49:16.479719
198	RUSFIRUB	RUSFIRUB	2019-04-01 17:49:16.51694	2019-04-01 17:49:16.51694
199	URSBRUB	URSBRUB	2019-04-01 17:49:16.523697	2019-04-01 17:49:16.523697
200	ABSTBRUB	ABSTBRUB	2019-04-01 17:49:16.530051	2019-04-01 17:49:16.530051
201	SPBBRUB	SPBBRUB	2019-04-01 17:49:16.535681	2019-04-01 17:49:16.535681
202	LCKBRUB	LCKBRUB	2019-04-01 17:49:16.542342	2019-04-01 17:49:16.542342
203	MSKCBRUB	MSKCBRUB	2019-04-01 17:49:16.548862	2019-04-01 17:49:16.548862
204	RSSBRUB	RSSBRUB	2019-04-01 17:49:16.556092	2019-04-01 17:49:16.556092
205	DMDNGBRUB	DMDNGBRUB	2019-04-01 17:49:16.562017	2019-04-01 17:49:16.562017
206	HCBRUB	HCBRUB	2019-04-01 17:49:16.567454	2019-04-01 17:49:16.567454
207	CRERBRUB	CRERBRUB	2019-04-01 17:49:16.57256	2019-04-01 17:49:16.57256
208	RSHBRUB	RSHBRUB	2019-04-01 17:49:16.577964	2019-04-01 17:49:16.577964
209	TRBRUB	TRBRUB	2019-04-01 17:49:16.583238	2019-04-01 17:49:16.583238
210	SVCMBRUB	SVCMBRUB	2019-04-01 17:49:16.588202	2019-04-01 17:49:16.588202
211	PLUSBRUB	PLUSBRUB	2019-04-01 17:49:16.593048	2019-04-01 17:49:16.593048
212	SMPBRUB	SMPBRUB	2019-04-01 17:49:16.597802	2019-04-01 17:49:16.597802
213	BALTBRUB	BALTBRUB	2019-04-01 17:49:16.603469	2019-04-01 17:49:16.603469
214	VZRDBRUB	VZRDBRUB	2019-04-01 17:49:16.613381	2019-04-01 17:49:16.613381
215	MOSBRUB	MOSBRUB	2019-04-01 17:49:16.620847	2019-04-01 17:49:16.620847
216	SVZBRUB	SVZBRUB	2019-04-01 17:49:16.627485	2019-04-01 17:49:16.627485
217	CTYBRUB	CTYBRUB	2019-04-01 17:49:16.632608	2019-04-01 17:49:16.632608
218	WURUB	WURUB	2019-04-01 17:49:16.637632	2019-04-01 17:49:16.637632
219	WUEUR	WUEUR	2019-04-01 17:49:16.643465	2019-04-01 17:49:16.643465
220	CNTEUR	CNTEUR	2019-04-01 17:49:16.6503	2019-04-01 17:49:16.6503
221	GCMTEUR	GCMTEUR	2019-04-01 17:49:16.656624	2019-04-01 17:49:16.656624
222	USTMEUR	USTMEUR	2019-04-01 17:49:16.663537	2019-04-01 17:49:16.663537
236	RKTBRUB	RKTBRUB	2019-04-01 17:49:20.337439	2019-04-01 17:49:20.337439
237	P24UAHnew	P24UAHnew	2019-04-01 17:49:20.353883	2019-04-01 17:49:20.353883
224	EDram	EDram	2019-04-01 17:49:16.919325	2019-04-01 17:49:16.919325
225	CPTSUSD	CPTSUSD	2019-04-01 17:49:16.925159	2019-04-01 17:49:16.925159
226	WEXUSD	WEXUSD	2019-04-01 17:49:16.938707	2019-04-01 17:49:16.938707
227	PMRUSD	PMRUSD	2019-04-01 17:49:16.943607	2019-04-01 17:49:16.943607
228	PAUSD	PAUSD	2019-04-01 17:49:16.948884	2019-04-01 17:49:16.948884
229	PMRRUB	PMRRUB	2019-04-01 17:49:16.955899	2019-04-01 17:49:16.955899
230	vivaroarmenia	vivaroarmenia	2019-04-01 17:49:16.958799	2019-04-01 17:49:16.958799
231	karabakhtelecom	karabakhtelecom	2019-04-01 17:49:16.962459	2019-04-01 17:49:16.962459
232	beelinearmenia	beelinearmenia	2019-04-01 17:49:16.965361	2019-04-01 17:49:16.965361
233	MTSarmenia	MTSarmenia	2019-04-01 17:49:16.968394	2019-04-01 17:49:16.968394
234	orangewebmoney	orangewebmoney	2019-04-01 17:49:16.971331	2019-04-01 17:49:16.971331
235	PMRUAH	PMRUAH	2019-04-01 17:49:16.974231	2019-04-01 17:49:16.974231
238	ADVCRUR	ADVCRUR	2019-04-01 17:53:38.127661	2019-04-01 17:53:38.127661
239	Boleto	Boleto	2019-04-01 17:53:38.140333	2019-04-01 17:53:38.140333
240	ECOPAYZ	ECOPAYZ	2019-04-01 17:53:38.168669	2019-04-01 17:53:38.168669
241	Binary	Binary	2019-04-01 17:53:38.175303	2019-04-01 17:53:38.175303
242	Gift Card 	Gift Card 	2019-04-01 17:53:38.181849	2019-04-01 17:53:38.181849
243	Astopaycard	Astopaycard	2019-04-01 17:53:38.188752	2019-04-01 17:53:38.188752
244	EPAYEUR	EPAYEUR	2019-04-01 17:53:38.197136	2019-04-01 17:53:38.197136
245	MMBUSD	MMBUSD	2019-04-01 17:53:38.203625	2019-04-01 17:53:38.203625
246	BNRUSD	BNRUSD	2019-04-01 17:53:39.93599	2019-04-01 17:53:39.93599
247	BBTC	BBTC	2019-04-01 17:54:09.429785	2019-04-01 17:54:09.429785
248	ACUAH	ACUAH	2019-04-01 17:54:17.228233	2019-04-01 17:54:17.228233
249	BCN	BCN	2019-04-01 17:55:09.138467	2019-04-01 17:55:09.138467
250	EXMUAH	EXMUAH	2019-04-01 17:55:37.548927	2019-04-01 17:55:37.548927
251	RIAUSD	RIAUSD	2019-04-01 17:55:46.417671	2019-04-01 17:55:46.417671
252	LCXEUR 	LCXEUR 	2019-04-01 17:55:46.426759	2019-04-01 17:55:46.426759
253	Sauliu bankas EUR	Sauliu bankas EUR	2019-04-01 17:55:46.435586	2019-04-01 17:55:46.435586
254	Maxipay	Maxipay	2019-04-01 17:55:46.448917	2019-04-01 17:55:46.448917
255	LVCNRUB	LVCNRUB	2019-04-01 17:56:14.117734	2019-04-01 17:56:14.117734
256	CPTSRUB	CPTSRUB	2019-04-01 17:56:14.128263	2019-04-01 17:56:14.128263
257	EDC	EDC	2019-04-01 17:56:14.139059	2019-04-01 17:56:14.139059
258	LVCNBTC	LVCNBTC	2019-04-01 17:56:14.16371	2019-04-01 17:56:14.16371
259	WEXRUB	WEXRUB	2019-04-01 18:04:43.287524	2019-04-01 18:04:43.287524
260	WEXEUR	WEXEUR	2019-04-01 18:04:43.303658	2019-04-01 18:04:43.303658
261	PMBTC	PMBTC	2019-04-01 18:04:43.32045	2019-04-01 18:04:43.32045
262	Dash	Dash	2019-04-01 18:05:46.129335	2019-04-01 18:05:46.129335
263	neo	neo	2019-04-01 18:05:46.160832	2019-04-01 18:05:46.160832
264	BINBRUB	BINBRUB	2019-04-01 18:05:46.183	2019-04-01 18:05:46.183
265	VTB24RUB	VTB24RUB	2019-04-01 18:05:49.360401	2019-04-01 18:05:49.360401
266	dash	dash	2019-04-01 18:05:49.421087	2019-04-01 18:05:49.421087
267	TCSBCRUB	TCSBCRUB	2019-04-01 18:05:49.447824	2019-04-01 18:05:49.447824
268	EXMOLTC	EXMOLTC	2019-04-01 18:06:50.463598	2019-04-01 18:06:50.463598
269	EXMOXRP	EXMOXRP	2019-04-01 18:06:50.472407	2019-04-01 18:06:50.472407
270	EXMOETH	EXMOETH	2019-04-01 18:06:50.481641	2019-04-01 18:06:50.481641
271	ECOPAYZEUR	ECOPAYZEUR	2019-04-01 18:06:50.786338	2019-04-01 18:06:50.786338
272	ECOPAYZUSD	ECOPAYZUSD	2019-04-01 18:06:50.814963	2019-04-01 18:06:50.814963
273	SKLGBP	SKLGBP	2019-04-01 18:06:50.864262	2019-04-01 18:06:50.864262
274	ECOPAYZRUB	ECOPAYZRUB	2019-04-01 18:06:50.970519	2019-04-01 18:06:50.970519
275	USDMSK	USDMSK	2019-04-01 18:08:31.166927	2019-04-01 18:08:31.166927
276	USDKiev	USDKiev	2019-04-01 18:08:31.175816	2019-04-01 18:08:31.175816
277	RFB	RFB	2019-04-01 18:09:05.764017	2019-04-01 18:09:05.764017
278	OPNRUB	OPNRUB	2019-04-01 18:09:05.775694	2019-04-01 18:09:05.775694
279	CARDGBP	CARDGBP	2019-04-01 18:09:41.167215	2019-04-01 18:09:41.167215
280	SEPAEUR	SEPAEUR	2019-04-01 18:09:41.189294	2019-04-01 18:09:41.189294
281	ESPUAUAH	ESPUAUAH	2019-04-01 18:10:42.08457	2019-04-01 18:10:42.08457
282	TerminalyiUkrainyi	TerminalyiUkrainyi	2019-04-01 18:10:42.121378	2019-04-01 18:10:42.121378
\.


--
-- Name: payment_systems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('payment_systems_id_seq', 282, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
20190322154337
20190322162724
20190323062837
20190325071958
20190401090734
20190401090735
20190401090736
20190401090737
20190401090738
20190401090739
20190401173730
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, name, email, crypted_password, salt, created_at, updated_at, remember_me_token, remember_me_token_expires_at, reset_password_token, reset_password_token_expires_at, reset_password_email_sent_at, access_count_to_reset_password_page, failed_logins_count, lock_expires_at, unlock_token, last_login_at, last_logout_at, last_activity_at, last_login_from_ip_address, activation_state, activation_token, activation_token_expires_at, is_admin) FROM stdin;
2	Alexey	fch.general@gmail.com	$2a$10$B3D2.Vt2LOO6FriaOGIsUOeU01AYbaJ3IXdbkoEKze1NTbUtrMEcC	WaX2GZefx_i-cyayjsEy	2019-04-01 17:28:05.811453	2019-04-02 09:05:39.6635	-APF1G7vbZARyues1c-U	2019-04-09 09:04:17.316582	\N	\N	\N	0	0	\N	\N	2019-04-02 09:04:17.321797	\N	2019-04-02 09:08:26.392479	46.187.32.77	\N	\N	\N	t
3	Ilya	frolov.ie@gmail.com	$2a$10$7atJoyuiA9wRnkUl6kaMBeRBApLaUiCunw6LDT8x6UOmHA05tK/bu	NAe6X6ysEZXuUCxZK1wY	2019-04-01 17:29:14.827632	2019-04-01 17:44:10.981403	pZQ_P4HjN3Ak535suSAv	2019-04-09 14:58:44.443768	\N	\N	\N	0	0	\N	\N	2019-04-02 14:58:44.450059	2019-04-01 18:35:33.003733	2019-04-03 06:50:10.025847	176.193.71.231	\N	\N	\N	t
1	Danil	danil@brandymint.ru	$2a$10$Fam4bNNd89dMXgrNj4FvjOgnhQgBGZkNgrpZOAluYbvdS6YjFa/qW	Lr9YsLt6z55q6_eDo15K	2019-04-01 17:27:46.438295	2019-04-01 17:27:46.438295	HLfxVwFcd29Cp5x-5hFH	2019-04-09 13:50:04.474674	\N	\N	\N	0	0	\N	\N	2019-04-02 13:50:04.480712	\N	2019-04-03 10:05:02.686032	46.187.42.78	\N	\N	\N	t
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 3, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: exchanges exchanges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY exchanges
    ADD CONSTRAINT exchanges_pkey PRIMARY KEY (id);


--
-- Name: payment_systems payment_systems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment_systems
    ADD CONSTRAINT payment_systems_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_exchanges_on_is_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_exchanges_on_is_available ON exchanges USING btree (is_available);


--
-- Name: index_exchanges_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_exchanges_on_name ON exchanges USING btree (name);


--
-- Name: index_exchanges_on_url; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_exchanges_on_url ON exchanges USING btree (url);


--
-- Name: index_payment_systems_on_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_payment_systems_on_code ON payment_systems USING btree (code);


--
-- Name: index_payment_systems_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_payment_systems_on_name ON payment_systems USING btree (name);


--
-- Name: index_users_on_activation_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_activation_token ON users USING btree (activation_token);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_last_logout_at_and_last_activity_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_last_logout_at_and_last_activity_at ON users USING btree (last_logout_at, last_activity_at);


--
-- Name: index_users_on_remember_me_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_remember_me_token ON users USING btree (remember_me_token);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: index_users_on_unlock_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_unlock_token ON users USING btree (unlock_token);


--
-- PostgreSQL database dump complete
--

